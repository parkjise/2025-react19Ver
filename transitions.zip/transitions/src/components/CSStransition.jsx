const CssTr = () => {
  return (
    <>
      <div>CSS TRANSITIONS</div>
    </>
    )
};

export default CssTr;