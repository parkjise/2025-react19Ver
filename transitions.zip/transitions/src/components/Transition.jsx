const TransitionComp = () => {
  return (
    <>
      <div>Transition</div>
    </>
  )
};

export default TransitionComp;